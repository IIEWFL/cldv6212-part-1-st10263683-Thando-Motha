﻿using Azure;
using Azure.Data.Tables;
using AbcRetailAzurePOE.Models;

namespace AbcRetailAzurePOE.Services
{
    public class ProductTableService
    {
        private readonly TableClient _tableClient;

        public ProductTableService(string storageConnectionString, string tableName = "Products")
        {
            _tableClient = new TableClient(storageConnectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        // CREATE
        public void AddProduct(ProductEntity product)
        {
            _tableClient.AddEntity(product);
        }

        // READ
        public IEnumerable<ProductEntity> GetAllProducts()
        {
            return _tableClient.Query<ProductEntity>();
        }

        public ProductEntity? GetProductById(string rowKey)
        {
            try
            {
                return _tableClient.GetEntity<ProductEntity>("PRODUCTS", rowKey).Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        // UPDATE
        public void UpdateProduct(ProductEntity product)
        {
            _tableClient.UpdateEntity(product, product.ETag, TableUpdateMode.Replace);
        }

        // DELETE
        public void DeleteProduct(string rowKey)
        {
            _tableClient.DeleteEntity("PRODUCTS", rowKey);
        }
    }
}
