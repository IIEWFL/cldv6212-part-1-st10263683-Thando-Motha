﻿using AbcRetailAzurePOE.Models;
using Azure;
using Azure.Data.Tables;

namespace AbcRetailAzurePOE.Services
{
    public class CustomerTableService
    {
        private readonly TableClient _tableClient;

        public CustomerTableService(string storageConnectionString, string tableName = "Customers")
        {
            _tableClient = new TableClient(storageConnectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        // CREATE
        public void AddCustomer(CustomerEntity customer) => _tableClient.AddEntity(customer);

        // READ
        public IEnumerable<CustomerEntity> GetAllCustomers() => _tableClient.Query<CustomerEntity>();

        public CustomerEntity? GetCustomerById(string rowKey)
        {
            try
            {
                return _tableClient.GetEntity<CustomerEntity>("CUSTOMERS", rowKey).Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        // UPDATE
        public void UpdateCustomer(CustomerEntity customer) =>
            _tableClient.UpdateEntity(customer, customer.ETag, TableUpdateMode.Replace);

        // DELETE
        public void DeleteCustomer(string rowKey) => _tableClient.DeleteEntity("CUSTOMERS", rowKey);
    }
}
