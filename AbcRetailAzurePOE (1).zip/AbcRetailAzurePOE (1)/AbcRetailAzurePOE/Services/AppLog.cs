﻿using System.Collections.Generic;

namespace AbcRetailAzurePOE.Services
{
   
    public static class AppLog
    {
        private static readonly object _lock = new();
        private static readonly Queue<string> _messages = new();
        private const int Max = 25;

        public static void Add(string message)
        {
            var line = $"{DateTime.Now:HH:mm:ss} — {message}";
            lock (_lock)
            {
                _messages.Enqueue(line);
                while (_messages.Count > Max) _messages.Dequeue();
            }
        }

        // Most-recent first
        public static List<string> Top(int n)
        {
            lock (_lock)
            {
                return _messages.Reverse().Take(n).ToList();
            }
        }
    }
}
