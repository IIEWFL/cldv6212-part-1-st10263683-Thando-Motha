﻿using Azure;
using Azure.Data.Tables;
using AbcRetailAzurePOE.Models;

namespace AbcRetailAzurePOE.Services
{
    public class OrderTableService
    {
        private readonly TableClient _tableClient;

        public OrderTableService(string storageConnectionString, string tableName = "Orders")
        {
            _tableClient = new TableClient(storageConnectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        // CREATE
        public void AddOrder(OrderEntity order) => _tableClient.AddEntity(order);

        // READ
        public IEnumerable<OrderEntity> GetAllOrders() => _tableClient.Query<OrderEntity>();

        public OrderEntity? GetOrderById(string rowKey)
        {
            try
            {
                return _tableClient.GetEntity<OrderEntity>("ORDERS", rowKey).Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        // UPDATE
        public void UpdateOrder(OrderEntity order) =>
            _tableClient.UpdateEntity(order, order.ETag, TableUpdateMode.Replace);

        // DELETE
        public void DeleteOrder(string rowKey) => _tableClient.DeleteEntity("ORDERS", rowKey);
    }
}
