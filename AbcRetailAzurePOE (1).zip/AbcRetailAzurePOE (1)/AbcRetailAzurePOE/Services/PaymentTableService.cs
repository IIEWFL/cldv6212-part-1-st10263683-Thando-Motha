﻿using Azure;
using Azure.Data.Tables;
using AbcRetailAzurePOE.Models;

namespace AbcRetailAzurePOE.Services
{
    public class PaymentTableService
    {
        private readonly TableClient _tableClient;

        public PaymentTableService(string storageConnectionString, string tableName = "Payments")
        {
            _tableClient = new TableClient(storageConnectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        // CREATE
        public void AddPayment(PaymentEntity payment)
        {
            _tableClient.AddEntity(payment);
        }

        // READ
        public IEnumerable<PaymentEntity> GetAllPayments()
        {
            return _tableClient.Query<PaymentEntity>();
        }

        public PaymentEntity? GetPaymentById(string rowKey)
        {
            try
            {
                return _tableClient.GetEntity<PaymentEntity>("PAYMENTS", rowKey).Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        // UPDATE
        public void UpdatePayment(PaymentEntity payment)
        {
            _tableClient.UpdateEntity(payment, payment.ETag, TableUpdateMode.Replace);
        }

        // DELETE
        public void DeletePayment(string rowKey)
        {
            _tableClient.DeleteEntity("PAYMENTS", rowKey);
        }
    }
}

