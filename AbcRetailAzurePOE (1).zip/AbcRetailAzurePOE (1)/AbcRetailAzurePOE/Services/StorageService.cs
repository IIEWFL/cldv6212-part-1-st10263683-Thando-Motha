﻿using Azure;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using AbcRetailAzurePOE.Models;
using Microsoft.AspNetCore.Http;

namespace AbcRetailAzurePOE.Services
{
    public class StorageService
    {
        private readonly string _connectionString;

        public StorageService(string connectionString)
        {
            _connectionString = connectionString;
        }

        // ---------------- TABLES ----------------
        public TableClient GetTable(string tableName)
        {
            var service = new TableServiceClient(_connectionString);
            var table = service.GetTableClient(tableName);
            table.CreateIfNotExists();
            return table;
        }

        public async Task AddCustomerAsync(CustomerEntity customer) =>
            await GetTable("Customers").AddEntityAsync(customer);

        public async Task<List<CustomerEntity>> ListCustomersAsync()
        {
            var list = new List<CustomerEntity>();
            await foreach (var entity in GetTable("Customers").QueryAsync<CustomerEntity>())
                list.Add(entity);
            return list;
        }

        // ---------------- BLOBS ----------------
        public BlobContainerClient GetBlobContainer(string containerName)
        {
            var container = new BlobContainerClient(_connectionString, containerName);
            container.CreateIfNotExists();
            return container;
        }

        public async Task<string> UploadBlobAsync(IFormFile file)
        {
            var container = GetBlobContainer("product-media");
            var blob = container.GetBlobClient($"{Guid.NewGuid()}_{file.FileName}");

            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, overwrite: true);

            return blob.Uri.ToString();
        }

        // ---------------- QUEUES ----------------
        public QueueClient GetQueue(string queueName)
        {
            var queue = new QueueClient(_connectionString, queueName);
            queue.CreateIfNotExists();
            return queue;
        }

        public async Task AddQueueMessageAsync(string message) =>
            await GetQueue("ops-events").SendMessageAsync(message);

        // ---------------- FILES ----------------
        public ShareClient GetFileShare(string shareName)
        {
            var share = new ShareClient(_connectionString, shareName);
            share.CreateIfNotExists();
            return share;
        }

        public async Task UploadContractAsync(IFormFile file)
        {
            var share = GetFileShare("contracts");
            var root = share.GetRootDirectoryClient();
            await root.CreateIfNotExistsAsync();

            var target = root.GetFileClient($"{Guid.NewGuid()}_{file.FileName}");
            await target.CreateAsync(file.Length);

            using var stream = file.OpenReadStream();
            await target.UploadAsync(stream);
        }
    }
}

