﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class ContractsController : Controller
    {
        private readonly IWebHostEnvironment _env;

        public ContractsController(IWebHostEnvironment env)
        {
            _env = env;
        }

        private string ContractsFolder()
        {
            var dir = Path.Combine(_env.WebRootPath, "contracts");
            Directory.CreateDirectory(dir);
            return dir;
        }

        public IActionResult Index()
        {
            var dir = ContractsFolder();
            var files = Directory.GetFiles(dir)
                                 .Select(p => new
                                 {
                                     Name = Path.GetFileName(p),
                                     Url = "/contracts/" + Path.GetFileName(p),
                                     Size = new FileInfo(p).Length,
                                     Modified = System.IO.File.GetLastWriteTime(p)
                                 })
                                 .OrderByDescending(f => f.Modified)
                                 .ToList();
            ViewBag.Files = files;
            return View();
        }

        [HttpGet]
        public IActionResult Upload() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ModelState.AddModelError("", "Please choose a file.");
                return View();
            }

            var dir = ContractsFolder();
            var safeName = Path.GetFileName(file.FileName);
            var path = Path.Combine(dir, safeName);

            using var stream = System.IO.File.Create(path);
            file.CopyTo(stream);

            AppLog.Add($"Contract uploaded: {safeName}");
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string name)
        {
            if (!string.IsNullOrWhiteSpace(name))
            {
                var path = Path.Combine(ContractsFolder(), Path.GetFileName(name));
                if (System.IO.File.Exists(path))
                {
                    System.IO.File.Delete(path);
                    AppLog.Add($"Contract deleted: {name}");
                }
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
