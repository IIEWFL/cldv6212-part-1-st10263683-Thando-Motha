﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Models;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class OrdersController : Controller
    {
        private readonly OrderTableService _orderService;

        public OrdersController(IConfiguration configuration)
        {
            var connString = configuration["StorageConnection:ConnectionString"]
                ?? throw new InvalidOperationException("Storage connection string not configured (StorageConnection:ConnectionString).");
            _orderService = new OrderTableService(connString);
        }

        public IActionResult Index()
        {
            var orders = _orderService.GetAllOrders().ToList();
            return View(orders);
        }

        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var order = _orderService.GetOrderById(id);
            if (order == null) return NotFound();
            return View(order);
        }

        [HttpGet] public IActionResult Create() => View(new OrderEntity());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(OrderEntity order)
        {
            if (!ModelState.IsValid) return View(order);
            order.PartitionKey ??= "ORDERS";
            order.RowKey ??= Guid.NewGuid().ToString();
            _orderService.AddOrder(order);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var order = _orderService.GetOrderById(id);
            if (order == null) return NotFound();
            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(OrderEntity order)
        {
            if (!ModelState.IsValid) return View(order);
            order.PartitionKey ??= "ORDERS";
            _orderService.UpdateOrder(order);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var order = _orderService.GetOrderById(id);
            if (order == null) return NotFound();
            return View(order);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            _orderService.DeleteOrder(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
