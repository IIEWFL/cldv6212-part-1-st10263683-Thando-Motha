﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Models;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductTableService _productService;

        public ProductsController(IConfiguration configuration)
        {
            var connString = configuration["StorageConnection:ConnectionString"]
                ?? throw new InvalidOperationException("Storage connection string not configured (StorageConnection:ConnectionString).");
            _productService = new ProductTableService(connString);
        }

        public IActionResult Index()
        {
            var products = _productService.GetAllProducts().ToList();
            return View(products);
        }

        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var product = _productService.GetProductById(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpGet] public IActionResult Create() => View(new ProductEntity());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ProductEntity product, IFormFile? imageFile)
        {
            if (!ModelState.IsValid) return View(product);

            // No blob upload — optional placeholder
            product.ImageUrl ??= "/images/placeholder.png";
            product.PartitionKey ??= "PRODUCTS";
            product.RowKey ??= Guid.NewGuid().ToString();

            _productService.AddProduct(product);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var product = _productService.GetProductById(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ProductEntity product, IFormFile? imageFile)
        {
            if (!ModelState.IsValid) return View(product);
            product.PartitionKey ??= "PRODUCTS";
            _productService.UpdateProduct(product);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var product = _productService.GetProductById(id);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            _productService.DeleteProduct(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
