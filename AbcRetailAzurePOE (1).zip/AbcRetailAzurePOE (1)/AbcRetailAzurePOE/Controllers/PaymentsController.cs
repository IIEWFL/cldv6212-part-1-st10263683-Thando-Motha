﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Models;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class PaymentsController : Controller
    {
        private readonly PaymentTableService _paymentService;

        public PaymentsController(IConfiguration configuration)
        {
            var connString = configuration["StorageConnection:ConnectionString"]
                ?? throw new InvalidOperationException("Storage connection string not configured (StorageConnection:ConnectionString).");
            _paymentService = new PaymentTableService(connString);
        }

        public IActionResult Index()
        {
            var payments = _paymentService.GetAllPayments().ToList();
            return View(payments);
        }

        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var payment = _paymentService.GetPaymentById(id);
            if (payment == null) return NotFound();
            return View(payment);
        }

        [HttpGet] public IActionResult Create() => View(new PaymentEntity());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(PaymentEntity payment)
        {
            if (!ModelState.IsValid) return View(payment);
            payment.PartitionKey ??= "PAYMENTS";
            payment.RowKey ??= Guid.NewGuid().ToString();
            _paymentService.AddPayment(payment);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var payment = _paymentService.GetPaymentById(id);
            if (payment == null) return NotFound();
            return View(payment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(PaymentEntity payment)
        {
            if (!ModelState.IsValid) return View(payment);
            payment.PartitionKey ??= "PAYMENTS";
            _paymentService.UpdatePayment(payment);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var payment = _paymentService.GetPaymentById(id);
            if (payment == null) return NotFound();
            return View(payment);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            _paymentService.DeletePayment(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
