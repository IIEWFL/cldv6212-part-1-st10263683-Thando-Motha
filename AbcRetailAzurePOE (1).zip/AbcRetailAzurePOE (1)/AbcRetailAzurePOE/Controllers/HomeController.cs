using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Models;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly string _connectionString;
        private readonly IWebHostEnvironment _env;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, IWebHostEnvironment env)
        {
            _logger = logger;
            _env = env;
            _connectionString = configuration["StorageConnection:ConnectionString"]
                ?? throw new InvalidOperationException("Storage connection string not configured (StorageConnection:ConnectionString).");
        }

        public IActionResult Index()
        {
            var customerSvc = new CustomerTableService(_connectionString);
            var productSvc = new ProductTableService(_connectionString);

            ViewBag.CustomerCount = customerSvc.GetAllCustomers().Count();
            ViewBag.ProductCount = productSvc.GetAllProducts().Count();

            // Basic local counts for uploads (no Azure)
            var uploadsDir = Path.Combine(_env.WebRootPath, "uploads");
            var contractsDir = Path.Combine(_env.WebRootPath, "contracts");
            ViewBag.MediaCount = Directory.Exists(uploadsDir) ? Directory.GetFiles(uploadsDir).Length : 0;
            ViewBag.ContractCount = Directory.Exists(contractsDir) ? Directory.GetFiles(contractsDir).Length : 0;

            // Queue/log (most recent first)
            ViewBag.QueueTop = AppLog.Top(10);
            return View();
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
