﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class MediaController : Controller
    {
        private readonly IWebHostEnvironment _env;

        public MediaController(IWebHostEnvironment env)
        {
            _env = env;
        }

        private string MediaFolder()
        {
            var dir = Path.Combine(_env.WebRootPath, "uploads");
            Directory.CreateDirectory(dir);
            return dir;
        }

        public IActionResult Index()
        {
            var dir = MediaFolder();
            var files = Directory.GetFiles(dir)
                                 .Select(p => new
                                 {
                                     Name = Path.GetFileName(p),
                                     Url = "/uploads/" + Path.GetFileName(p),
                                     Size = new FileInfo(p).Length,
                                     Modified = System.IO.File.GetLastWriteTime(p)
                                 })
                                 .OrderByDescending(f => f.Modified)
                                 .ToList();
            ViewBag.Files = files;
            return View();
        }

        [HttpGet]
        public IActionResult Upload() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ModelState.AddModelError("", "Please choose a file.");
                return View();
            }

            var dir = MediaFolder();
            var safeName = Path.GetFileName(file.FileName);
            var path = Path.Combine(dir, safeName);

            using var stream = System.IO.File.Create(path);
            file.CopyTo(stream);

            AppLog.Add($"Media uploaded: {safeName}");
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string name)
        {
            if (!string.IsNullOrWhiteSpace(name))
            {
                var path = Path.Combine(MediaFolder(), Path.GetFileName(name));
                if (System.IO.File.Exists(path))
                {
                    System.IO.File.Delete(path);
                    AppLog.Add($"Media deleted: {name}");
                }
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
