﻿using Microsoft.AspNetCore.Mvc;
using AbcRetailAzurePOE.Models;
using AbcRetailAzurePOE.Services;

namespace AbcRetailAzurePOE.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerTableService _customerService;

        public CustomersController(IConfiguration configuration)
        {
            var connString = configuration["StorageConnection:ConnectionString"]
                ?? throw new InvalidOperationException("Storage connection string not configured (StorageConnection:ConnectionString).");
            _customerService = new CustomerTableService(connString);
        }

        public IActionResult Index()
        {
            var customers = _customerService.GetAllCustomers().ToList();
            return View(customers);
        }

        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var customer = _customerService.GetCustomerById(id);
            if (customer == null) return NotFound();
            return View(customer);
        }

        [HttpGet] public IActionResult Create() => View(new CustomerEntity());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CustomerEntity customer)
        {
            if (!ModelState.IsValid) return View(customer);
            customer.PartitionKey ??= "CUSTOMERS";
            customer.RowKey ??= Guid.NewGuid().ToString();
            _customerService.AddCustomer(customer);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var customer = _customerService.GetCustomerById(id);
            if (customer == null) return NotFound();
            return View(customer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CustomerEntity customer)
        {
            if (!ModelState.IsValid) return View(customer);
            customer.PartitionKey ??= "CUSTOMERS";
            _customerService.UpdateCustomer(customer);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var customer = _customerService.GetCustomerById(id);
            if (customer == null) return NotFound();
            return View(customer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            _customerService.DeleteCustomer(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
