﻿using Azure;
using Azure.Data.Tables;

namespace AbcRetailAzurePOE.Models
{
    public class CustomerEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "CUSTOMERS";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
