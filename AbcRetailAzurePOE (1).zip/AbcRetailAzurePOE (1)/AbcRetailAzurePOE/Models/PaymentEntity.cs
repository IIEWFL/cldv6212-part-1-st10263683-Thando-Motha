﻿using Azure;
using Azure.Data.Tables;

namespace AbcRetailAzurePOE.Models
{
    public class PaymentEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "PAYMENTS";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        // Match the view columns
        public string OrderId { get; set; } = null!;         // corresponds to OrderRef
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; } = null!;   // corresponds to Method
        public DateTimeOffset PaymentDate { get; set; } = DateTimeOffset.UtcNow;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
