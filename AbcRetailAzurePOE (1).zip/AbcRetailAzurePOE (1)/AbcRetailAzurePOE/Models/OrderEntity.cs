﻿using Azure;
using Azure.Data.Tables;

namespace AbcRetailAzurePOE.Models
{
    public class OrderEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "ORDERS";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        public string CustomerName { get; set; } = null!;
        public string ProductName { get; set; } = null!;
        public int Quantity { get; set; } = 1;
        public DateTimeOffset OrderDate { get; set; } = DateTimeOffset.UtcNow;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}

