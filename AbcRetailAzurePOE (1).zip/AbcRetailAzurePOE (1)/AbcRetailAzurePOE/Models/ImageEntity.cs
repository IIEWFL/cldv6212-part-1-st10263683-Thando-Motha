﻿using Azure;
using Azure.Data.Tables;

namespace AbcRetailAzurePOE.Models
{
    public class ImageEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "IMAGES";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();

        public string FileName { get; set; } = null!;
        public string Url { get; set; } = null!;
        public string? ContentType { get; set; }
        public DateTimeOffset UploadedOn { get; set; } = DateTimeOffset.UtcNow;

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
